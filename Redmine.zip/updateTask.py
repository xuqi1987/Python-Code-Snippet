#!/usr/bin/env python
# -*- coding: utf-8 -*-
# author: liujun
# Modify LOG: 
# 2015/4/7  15:00 new create
# 2015/4/16   16:00 liujun modify  if minuter is 0, output '00'
# 2015/4/17 12:00  liujun modify output log for redmine whether outputlog have error log
# 2015/4/23 liujun delete date compare and % is set 10%unit and ?->・
# 2015/4/28 liujun  read the cell I3 in anyplaceProject xls file, to juede T or L

import sys
import os
import time
import excelFormatDef
import xlwt
from excelOpeLib import xlsRWLib
import datetime
from redmine import Redmine

from gerrit import Gerrit

AP_TOYOTA_DATA = 'T_DCUMEUMIST'
AP_LEXUS_DATA = 'L_DCUMEUMIST'

class RedmineHelp():
    def __init__(self):
        self.XlsFile = None
        self.RMDataList = []
        self.WebRMDataList = []
        self.LoadRMDataOK = False
        self.redmine = Redmine('http://172.26.14.57:3000/', key='1cb880c401e940a589768f96a6ba6528bda87959')
        self.project = 'cy_task_meuui_meuui'

        pass

    def loadRedmineDataFromExcel(self, redmineExportXls):
        self.RMDataXls = redmineExportXls
        try:
            self.XlsFile = xlsRWLib(self.RMDataXls)
            self.XlsFile.openReadExcel()
            strSheetName = excelFormatDef.RM_DATA_SHEET_NAME
            taskid = self.XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_TASK_ID, 1 )
            taskfollow = self.XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_TASK_FOLLOW, 1 )
            taskstatus = self.XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_STATUS, 1 )
            taskName = self.XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_TASK, 1 )
            taskowner  = self.XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_OWNER, 1 )
            endSchedule = self.XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_FINISH_DAILY, 1 )
            startDate = self.XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_START_DAILY, 1 )
            taskProgress = self.XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_PROGRESS, 1 )
            taskTimer = self.XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_TIMER, 1 )
            taskComment = self.XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_COMMENT, 1 )
            taskLink = self.XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_LINK, 1 )
            taskVersion = self.XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_VERSION, 1 )
            self.LoadRMDataOK = True

        except:
            self.LoadRMDataOK = False
            print('>>>>>ERROR: open %s excel file failed,please input the address is ok?!' % (self.RMDataXls))
            return
        for i in range(0, len(taskName)):
            #print taskowner[i]
            self.RMDataList += [{'taskid':taskid[i],'taskstatus':taskstatus[i],'taskowner':taskowner[i],'taskTimer':taskTimer[i],'taskProgress':taskProgress[i],'taskComment':taskComment[i],'taskLink':taskLink[i],'taskVersion':taskVersion[i]}]
        pass


    def loadRedmineDataFromWeb(self):
        # finish task
        issues = self.redmine.issue.all(project_id=self.project,status_id='closed')
        for issue in issues:
            webtaskid = issue.id
            taskid = issue.custom_fields[0].value
            designlink = issue.custom_fields[3].value
            minuteslink = issue.custom_fields[4].value
            if designlink == 0:
                designlink = ''
            if minuteslink == 0:
                minuteslink = ''
            taskLinks = []
            taskLinks += [designlink]
            taskLinks += [minuteslink]
            #taskLinks = self.splitlink(taskLink)
            #only this time
            #self.updateRedmineWebLink(issue,taskLinks)

            taskName = issue.custom_fields[2].value
            taskstatus=u'Resolved'
            #print taskName
            taskowner = u'UI 张庆红'

            taskTimer = excelFormatDef.TIME[taskName]

            taskProgress = u'100'
            taskComment = ''
            taskVersion = u'1.00'
            print('Task Finish:%s %s %s' % (issue.custom_fields[1].value,taskName,taskLinks))
            self.WebRMDataList +=  [{'id':webtaskid,'screenName':issue.custom_fields[1].value,'taskName':taskName,'taskid':taskid,'taskstatus':taskstatus,'taskowner':taskowner,'taskTimer':taskTimer,'taskProgress':taskProgress,'taskComment':taskComment,'taskLinks':taskLinks,'taskVersion':taskVersion}]
        pass

    def splitlink(self,links):
        if links == 0:
             links = ''
        linklist = []
            # check link
        if links.find('xls;') >0:
                for  link in  links.split('xls;'):
                    if not link.endswith('xls'):
                        if (len(link) >0):
                            link = link + 'xls'
                    linklist.append(link)
        else:
                for  link in  links.split(' '):
                    if (len(link) >0):
                        linklist.append(link)

        if len(linklist)<=1:
            return linklist
        if linklist[0].find('minutes') >0:
             linklist.reverse()   
        return   linklist                                                                                                                                                   
        pass

    def updateRedmineWebLink(self,issue,links):
        print dir(issue)
        if len(links) == 2:
            print self.redmine.issue.update(issue.id, custom_fields=[{'id': 13, 'value': links[0]}, {'id': 12, 'value': links[1]}])
        elif len(links) == 1:
            print self.redmine.issue.update(issue.id, custom_fields=[{'id': 13, 'value': links[0]}])
        else:
            pass
        pass

    def updateRedmine(self):
        self.XlsFile.openWriteExcel()
        print  "\n=============================Report==================================="
        for torow in range(0, len(self.RMDataList)):
            for fromrow in  range(0, len(self.WebRMDataList)):
                if  self.WebRMDataList[fromrow]['taskid'] == self.RMDataList[torow]['taskid'] and self.RMDataList[torow]['taskowner']  == u'UI 徐琪':
                    print "============!!!!!!================"
                    print self.RMDataList[torow]['taskstatus']
                    print (('Screen:%s TaskName :%s  ID:%s %s')% (self.WebRMDataList[fromrow]['screenName'],self.WebRMDataList[fromrow]['taskName'],self.WebRMDataList[fromrow]['taskid'],self.WebRMDataList[fromrow]['taskLinks']))
                    taskstatus = self.WebRMDataList[fromrow]['taskstatus']
                    taskowner = self.WebRMDataList[fromrow]['taskowner']
                    taskProgress =  self.WebRMDataList[fromrow]['taskProgress']
                    taskLinks =  self.WebRMDataList[fromrow]['taskLinks']
                    taskVersion  =self.WebRMDataList[fromrow]['taskVersion']
                    taskTimer = self.WebRMDataList[fromrow]['taskTimer']

                    writeSheetIndex = self.XlsFile.getSheetIndexByName(excelFormatDef.RM_DATA_SHEET_NAME)

                    self.XlsFile.setCellVal(writeSheetIndex,torow+1,16,'xuqi')
                    self.XlsFile.setCellVal(writeSheetIndex,torow+1,excelFormatDef.RM_COL_STATUS,taskstatus)
                    self.XlsFile.setCellVal(writeSheetIndex,torow+1,excelFormatDef.RM_COL_OWNER,taskowner)
                    self.XlsFile.setCellVal(writeSheetIndex,torow+1,excelFormatDef.RM_COL_PROGRESS,taskProgress)
                    self.XlsFile.setCellVal(writeSheetIndex,torow+1,excelFormatDef.RM_COL_TIMER,taskTimer)

                    if len(taskLinks) >0:
                        self.XlsFile.setCellVal(writeSheetIndex,torow+1,excelFormatDef.RM_COL_LINK,taskLinks)
                        self.XlsFile.setCellVal(writeSheetIndex,torow+1,excelFormatDef.RM_COL_VERSION,taskVersion)

        self.XlsFile.saveExcel()
        pass
    
    def createRedmineIssue(self,task,screen,taskname):
        print screen
        issue = self.redmine.issue.new()
        issue.project_id = self.project
        issue.subject = task['taskName']
        issue.tracker_id = 5
        issue.description = ''
        issue.status_id = 3
        issue.done_ratio = task['taskProgress']
        issue.assigned_to_id = excelFormatDef.SCREEN[screen]
        issue.watcher_user_ids = self.getWatcher(excelFormatDef.SCREEN[screen])
        issue.custom_fields = [{'id': 1, 'value': task['taskid']},{'id': 2, 'value': screen},{'id': 3, 'value': taskname}]
        issue.due_date = datetime.datetime.strptime(str(task['endSchedule']), "%Y-%m-%d").date() - 7
        issue.start_date = datetime.datetime.strptime(str(task['startDate']), "%Y-%m-%d").date() -7
        issue.save()
        pass

    def getWatcher(self,user):
        watcher = []
        if user == excelFormatDef.USER_CC:
            watcher = [excelFormatDef.USER_SGX]
        elif user == excelFormatDef.USER_CP:
            watcher = [excelFormatDef.USER_WL]
        else:
            pass
        watcher += [excelFormatDef.USER_XQ]
        return watcher

    def reportSchedule(self):
        # check data load success?
        if not self.LoadRMDataOK:
            print '#####>>>>>>>##### Have Error! RUN STOP!!!!!!'
            return
        pass


    def update(self,excel):
         #data load
        self.loadRedmineDataFromExcel(excel)
        self.loadRedmineDataFromWeb()
        self.updateRedmine()
        pass

    def check(self):
        self.loadRedmineDataFromWeb()

        gerrit = Gerrit("aQIkprqB4-UXinBPaBZZW3a2SCB8ycw7Oq")
        for fromrow in  range(0, len(self.WebRMDataList)):
            taskLinks =  self.WebRMDataList[fromrow]['taskLinks']
            taskid = self.WebRMDataList[fromrow]['id']
            if len(taskLinks) > 0:
                for link in taskLinks:
                        if len(link) > 0:
                            code =  gerrit.getRequset(link) 
                            if code == 200:
                                pass
                            else:
                                print "NG\t%s" % link
                                print taskid
                                self.redmine.issue.update(taskid,notes=u"链接错误,请修正链接:%s"%link)
        pass




def updateTask(redmineExportXls):
    if not os.path.exists(redmineExportXls) :
        print ' ERROR ^^^^^^File is not exist,please input right parameters!'
        return

    reportObj =  RedmineHelp()
    reportObj.update(redmineExportXls)
    pass

def checkLink():
    reportObj =  RedmineHelp()
    reportObj.check()
    pass

def printHelp():
    print '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>'
    print 'use methion case1:create anyplace Schedule. \n ./redmineToAP.py --create --createType redmineScheduleFile screenListFile'
    print 'createType value is {scrn,mist},other valune cannot use'
    print 'if createType is mist, it need not to set screenListFile param '
    print 'use methion case2:report anyplace Schedule. \n ./redmineToAP.py --report TaskForDataInputExcel redmineExportExcel'
    pass
    
def main():
    # load programm's argc
    argvLen = len(sys.argv) - 1
    if argvLen > 0:    
        if '--help' == sys.argv[1]:
            printHelp()
        elif '--plan' == sys.argv[1]:
            if argvLen < 2:
                print ' ERROR ^^^^^^command param is not enough'
                printHelp()
            else:
                #run report command
                createTask(sys.argv[2])
                pass            
            pass
        elif '--update' == sys.argv[1]:
            if argvLen < 2:
                print ' ERROR ^^^^^^command param is not enough'
                printHelp()
            else:
                #run report command
                updateTask(sys.argv[2])
                pass            
            pass
        elif '--check' ==  sys.argv[1]:
                #run report command
                checkLink()
                pass            

        else:
            print ' ERROR ^^^^^^input command parameters have error'
            printHelp()
    else:
        print ' ERROR ^^^^^^please input command parameters'
        printHelp()    
    pass
    
if __name__ == '__main__':
    main()
    pass
