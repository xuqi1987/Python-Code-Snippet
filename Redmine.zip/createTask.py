#!/usr/bin/env python
# -*- coding: utf-8 -*-
# author: liujun
# Modify LOG: 
# 2015/4/7  15:00 new create
# 2015/4/16   16:00 liujun modify  if minuter is 0, output '00'
# 2015/4/17 12:00  liujun modify output log for redmine whether outputlog have error log
# 2015/4/23 liujun delete date compare and % is set 10%unit and ?->・
# 2015/4/28 liujun  read the cell I3 in anyplaceProject xls file, to juede T or L

import sys
import os
import time
import excelFormatDef
import xlwt
from excelOpeLib import xlsRWLib
import datetime
from redmine import Redmine


AP_TOYOTA_DATA = 'T_DCUMEUMIST'
AP_LEXUS_DATA = 'L_DCUMEUMIST'

class CreateRedmine():
    def __init__(self, redmineExportXls):
        self.RMDataXls = redmineExportXls
        self.RMDataList = []
        self.LoadRMDataOK = False
        self.redmine = Redmine('http://172.26.14.57:3000/', key='1cb880c401e940a589768f96a6ba6528bda87959')
        self.project = 'cy_task_meuui_meuui'
        #data load
        self.loadRedmineData()

        pass
        
    def loadRedmineData(self):
        try:
            XlsFile = xlsRWLib(self.RMDataXls)
            XlsFile.openReadExcel()
            strSheetName = excelFormatDef.RM_DATA_SHEET_NAME
            taskid = XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_TASK_ID, 1 )
            taskfollow = XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_TASK_FOLLOW, 1 )
            taskName = XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_TASK, 1 )
            endSchedule = XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_FINISH_DAILY, 1 )
            startDate = XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_START_DAILY, 1 )
            taskProgress = XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_PROGRESS, 1 )
            taskTimer = XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_TIMER, 1 )
            taskComment = XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_COMMENT, 1 )

            self.LoadRMDataOK = True
        except:
            self.LoadRMDataOK = False
            print('>>>>>ERROR: open %s excel file failed,please input the address is ok?!' % (self.RMDataXls))
            return
        for i in range(0, len(taskName)):
            task= {'taskName':taskName[i],'endSchedule':endSchedule[i],'taskProgress':taskProgress[i],'taskTimer':taskTimer[i],'taskComment':taskComment[i],'taskid':taskid[i],'taskFollow':taskfollow[i],'startDate':startDate[i]}
            if task['taskName'].find('MM') > 0:
                self.RMDataList += [task]
                startIndex = task['taskName'].find('MM')
                endIndex = task['taskName'].find(' ')
                screenid =  str(task['taskName'][startIndex:endIndex])
                taskname = task['taskName'][0:startIndex-1]
                if excelFormatDef.SCREEN.has_key(screenid):
                    self.createRedmineIssue(task,screenid,taskname)
        pass

    def createRedmineIssue(self,task,screen,taskname):
        print screen
        issue = self.redmine.issue.new()
        issue.project_id = self.project
        issue.subject = task['taskName']
        issue.tracker_id = 5
        issue.description = ''
        issue.status_id = 3
        issue.done_ratio = task['taskProgress']
        issue.assigned_to_id = excelFormatDef.SCREEN[screen]
        #issue.watcher_user_ids = self.getWatcher(excelFormatDef.SCREEN[screen])
        issue.custom_fields = [{'id': 1, 'value': task['taskid']},{'id': 2, 'value': screen},{'id': 3, 'value': taskname}]
        issue.due_date = datetime.datetime.strptime(str(task['endSchedule']), "%Y-%m-%d").date()
        issue.start_date = datetime.datetime.strptime(str(task['startDate']), "%Y-%m-%d").date()
        issue.save()
        pass

    def getWatcher(self,user):
        watcher = []
        if user == excelFormatDef.USER_CC:
            watcher = [excelFormatDef.USER_SGX]
        elif user == excelFormatDef.USER_CP:
            watcher = [excelFormatDef.USER_WL]
        else:
            pass
        watcher += [excelFormatDef.USER_XQ]
        return watcher

    def reportSchedule(self):
        # check data load success?
        if not self.LoadRMDataOK:
            print '#####>>>>>>>##### Have Error! RUN STOP!!!!!!'
            return
        pass

def createTask(redmineExportXls):
    if not os.path.exists(redmineExportXls) :
        print ' ERROR ^^^^^^File is not exist,please input right parameters!'
        return
    reportObj = CreateRedmine(redmineExportXls)
    #reportObj.reportSchedule()
    pass    

def printHelp():
    print '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>'
    print 'use methion case1:create anyplace Schedule. \n ./redmineToAP.py --create --createType redmineScheduleFile screenListFile'
    print 'createType value is {scrn,mist},other valune cannot use'
    print 'if createType is mist, it need not to set screenListFile param '
    print 'use methion case2:report anyplace Schedule. \n ./redmineToAP.py --report TaskForDataInputExcel redmineExportExcel'
    pass
    
def main():
    # load programm's argc
    argvLen = len(sys.argv) - 1
    if argvLen > 0:    
        if '--help' == sys.argv[1]:
            printHelp()
        elif '--plan' == sys.argv[1]:
            if argvLen < 2:
                print ' ERROR ^^^^^^command param is not enough'
                printHelp()
            else:
                #run report command
                createTask(sys.argv[2])
                pass            
            pass
        else:
            print ' ERROR ^^^^^^input command parameters have error'
            printHelp()
    else:
        print ' ERROR ^^^^^^please input command parameters'
        printHelp()    
    pass
    
if __name__ == '__main__':
    main()
    pass
