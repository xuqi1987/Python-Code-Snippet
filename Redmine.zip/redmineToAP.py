#!/usr/bin/env python
# -*- coding: utf-8 -*-
# author: liujun
# Modify LOG: 
# 2015/4/7  15:00 new create
# 2015/4/16   16:00 liujun modify  if minuter is 0, output '00'
# 2015/4/17 12:00  liujun modify output log for redmine whether outputlog have error log
# 2015/4/23 liujun delete date compare and % is set 10%unit and ?->・
# 2015/4/28 liujun  read the cell I3 in anyplaceProject xls file, to juede T or L

import sys
import os
import time
import excelFormatDef
import xlwt
from excelOpeLib import xlsRWLib
import datetime

AP_TOYOTA_DATA = 'T_DCUMEUMIST'
AP_LEXUS_DATA = 'L_DCUMEUMIST'

class RedmineToAP():
    def __init__(self, RMFile):
        self.RMFile = RMFile
        #self.APFile = APFile
        self.SLFile = ''
        self.RMData = []
        self.LoadRMDataOK = False
        #self.APData = []
        self.SLData = []
        self.LoadSLDataOK = False
        self.ApXls = None
        
    def setScrnListFileAddr(self, SLFile):
        self.SLFile = SLFile
        pass
    
    def loadRedmineData(self, createType):
        try:
            XlsFile = xlsRWLib(self.RMFile)
            XlsFile.openReadExcel()
            strSheetName = ''
            if excelFormatDef.RMAP_CREATE_TYPE_SCRN == createType:
                strSheetName = excelFormatDef.RM_SCRN_SHEET_NAME
            else:
                strSheetName = excelFormatDef.RM_MIST_SHEET_NAME
            fatherTask = XlsFile.getColVal(strSheetName, excelFormatDef.RM_SCRN_UNIT_COL, excelFormatDef.RM_DATA_START_ROW )
            mainTask = XlsFile.getColVal(strSheetName, excelFormatDef.RM_TASK_UNIT_COL, excelFormatDef.RM_DATA_START_ROW )
            members = XlsFile.getColVal(strSheetName, excelFormatDef.RM_MEMBER_UNIT_COL, excelFormatDef.RM_DATA_START_ROW )
            startTimer = XlsFile.getColVal(strSheetName, excelFormatDef.RM_START_SCHEDULE_COL, excelFormatDef.RM_DATA_START_ROW )
            endTimer = XlsFile.getColVal(strSheetName, excelFormatDef.RM_END_SCHEDULE_COL, excelFormatDef.RM_DATA_START_ROW )
            taskType = XlsFile.getColVal(strSheetName, excelFormatDef.RM_TASK_TYPE_COL, excelFormatDef.RM_DATA_START_ROW )
            self.LoadRMDataOK = True
        except:
            self.LoadRMDataOK = False
            print('>>>>>ERROR: open %s excel file failed,please input the address is ok?!' % (self.RMFile))
            return
        for i in range(0, len(mainTask)):
            self.RMData += [{'fatherTask':fatherTask[i],'mainTask':mainTask[i],'members':members[i],'startTimer':startTimer[i],'endTimer':endTimer[i],'taskType':taskType[i] }]
        pass
        
    def loadScrnListData(self):
        try:
            XlsFile = xlsRWLib(self.SLFile)
            XlsFile.openReadExcel()
            scrnNo = XlsFile.getColVal(excelFormatDef.SL_SHEET_NAME, excelFormatDef.SL_SCRN_NO_COL, excelFormatDef.SL_DATA_START_ROW )
            hardType = XlsFile.getColVal(excelFormatDef.SL_SHEET_NAME, excelFormatDef.SL_HARD_COL, excelFormatDef.SL_DATA_START_ROW )
            #modelType = XlsFile.getColVal(excelFormatDef.SL_SHEET_NAME, excelFormatDef.SL_MODEL_COL, excelFormatDef.SL_DATA_START_ROW )
            displayType = XlsFile.getColVal(excelFormatDef.SL_SHEET_NAME, excelFormatDef.SL_DISPLAY_COL, excelFormatDef.SL_DATA_START_ROW )
            self.LoadSLDataOK = True
        except:
            self.LoadSLDataOK = False
            print('>>>>>ERROR: open %s excel file failed,please input the address is ok?!' % (self.SLFile))
            return
        for i in range(0, len(scrnNo)):
            #self.SLData += [{'scrnNo':scrnNo[i],'hardType':hardType[i],'modelType':modelType[i]}]        
            #self.SLData += [{'scrnNo':scrnNo[i],'hardType':hardType[i]}]        
            self.SLData += [{'scrnNo':scrnNo[i],'hardType':hardType[i],'displayType':displayType[i]}]
        pass
        
    def getHardFromSLData(self, scrnNo):
        # return string: Dcu Meu DcuMeu errorList
        strScrnHard = 'errorList'
        scrnInfo = ''
        # get scrnNo from function param
        fatherTask = scrnNo.strip()
        if '' == fatherTask:
            return strScrnHard
        else:
            scrnInfo = fatherTask.split(' ')
        if len(scrnInfo) >= 2:
            scrnId = scrnInfo[0]
        #print scrnId
        for slData in self.SLData:
            if scrnId == slData['scrnNo']:
                scrnHard = slData['hardType']
                #print scrnHard
                #scrnModel = slData['modelType']
                if excelFormatDef.SL_HARD_TYPE_DCU == scrnHard:
                    strScrnHard = 'Dcu'
                elif excelFormatDef.SL_HARD_TYPE_MEU == scrnHard:
                    strScrnHard = 'Meu'
                elif excelFormatDef.SL_HARD_TYPE_COMMON == scrnHard:
                    strScrnHard = 'DcuMeu'
                else:
                    strScrnHard = 'errorList'
                pass

        #print('$$$$$$$$$$$$$ function findHardFromSLData return %s ' % (strScrnHard))
        return strScrnHard
        pass
    
    def getDisplayFromSLData(self, scrnNo):
        # return string: Wide Narrow Common errorDisplay
        strScrnDisplay = 'errorDisplay'
        scrnInfo = ''
        # get scrnNo from function param
        fatherTask = scrnNo.strip()
        if '' == fatherTask:
            return strScrnDisplay
        else:
            scrnInfo = fatherTask.split(' ')
        if len(scrnInfo) >= 2:
            scrnId = scrnInfo[0]
        #print scrnId
        for slData in self.SLData:
            if scrnId == slData['scrnNo']:
                scrnDisplay = slData['displayType']
                #print scrnHard
                #scrnModel = slData['modelType']
                if excelFormatDef.SL_DISPLAY_TYPE_WIDE == scrnDisplay:
                    strScrnDisplay = 'Wide'
                elif excelFormatDef.SL_DISPLAY_TYPE_NARROW == scrnDisplay:
                    strScrnDisplay = 'Narrow'
                elif excelFormatDef.SL_DISPLAY_TYPE_COMMON == scrnDisplay:
                    strScrnDisplay = 'Common'
                else:
                    strScrnDisplay = 'errorDisplay'
                pass

        #print('$$$$$$$$$$$$$ function getDisplayFromSLData return %s ' % (strScrnDisplay))
        return strScrnDisplay
        pass
        
    def getScrnNameFromRmData(self, rmFatherTask):
        fatherTask = rmFatherTask.strip()
        scrnName = fatherTask
        scrnInfo = ''
        if '' == fatherTask:
            return scrnName
        else:
            scrnInfo = fatherTask.split(' ')
        scrnName = ''
        if len(scrnInfo) >= 2:
            for i in range(1, len(scrnInfo)):
                scrnName += scrnInfo[i] + ' '
        scrnName = scrnName.strip()
        return scrnName
        pass
        
    def isTaskFromRmData(self, mainTask):
        isTask = False
        if '' == mainTask:
            isTask = False
        else:
            if -1 != mainTask.find(excelFormatDef.RM_TASK_FLAG):
                isTask = True
            else:
                isTask = False
        return isTask
        pass
        
    def getTaskNameFromRmData(self, mainTask):
        taskName = ''
        if '' == mainTask:
            return mainTask
        else:
            strMainTask = mainTask.replace('_', ' ')
            strMainTask = strMainTask.strip()
            taskTmp = strMainTask.split(' ')
            taskName = taskTmp[0]
        return taskName
        pass

    def getTaskModelFromRmData(self, mainTask):
        # return Common L T
        taskModel = ''
        if '' == mainTask:
            return mainTask
        else:
            strMainTask = mainTask.replace('_', ' ')
            strMainTask = strMainTask.strip()
            taskTmp = strMainTask.split(' ')
            taskModel = taskTmp[-1]
        return taskModel
        pass

    def getTaskTypeFromRmData(self, taskType):
        # return AP_TASK_TYPE_BD ...
        apTaskType = excelFormatDef.AP_TASK_TYPE_BD

        strTaskType = taskType.strip()
        if excelFormatDef.RM_TASK_TYPE_BD == strTaskType:
            apTaskType = excelFormatDef.AP_TASK_TYPE_BD
        elif excelFormatDef.RM_TASK_TYPE_DD == strTaskType:
            apTaskType = excelFormatDef.AP_TASK_TYPE_DD
        elif excelFormatDef.RM_TASK_TYPE_CODE == strTaskType:
            apTaskType = excelFormatDef.AP_TASK_TYPE_CODE
        elif excelFormatDef.RM_TASK_TYPE_UT == strTaskType:
            apTaskType = excelFormatDef.AP_TASK_TYPE_UT
        elif excelFormatDef.RM_TASK_TYPE_ST == strTaskType:
            apTaskType = excelFormatDef.AP_TASK_TYPE_ST
        else:
            pass
        return apTaskType
        pass
    
    def createMistAnyplace(self, createType):
        #load excel data
        self.loadRedmineData(createType)
        # add hard-model data xls
        ApDatabook = xlwt.Workbook(encoding='utf-8')
        LexusSheet = ApDatabook.add_sheet('Lexus', cell_overwrite_ok=True)
        ToyotaSheet = ApDatabook.add_sheet('Toyota', cell_overwrite_ok=True)
        noScrnSheet = ApDatabook.add_sheet('errorList', cell_overwrite_ok=True)
        tmpApStartRow = excelFormatDef.AP_SHEET_START_ROW
        sheetCurRowNum = {'Lexus':tmpApStartRow, 'Toyota':tmpApStartRow}
        noCreateScrn = ''
        modelNotAll = ''
        for iRM in range(0, len(self.RMData)):
            #print rmData['fatherTask']
            scrnName = ''
            taskModel = ''
            apTaskName = ''
            apTaskType = ''
            if self.RMData[iRM]['fatherTask'] != '':
                scrnName = self.getScrnNameFromRmData(self.RMData[iRM]['fatherTask'])
                # check There is really T or L, when there is Common
                tmpTaskModel = ''
                haveTForCommon = False
                haveLForCommon = False
                for iCheckTask in range(iRM + 1, iRM+1+excelFormatDef.RM_TASK_MAX_NUM):                    
                    if iCheckTask >= len(self.RMData):
                        break
                    if self.RMData[iCheckTask]['mainTask'] == '':
                        break
                    if  self.isTaskFromRmData(self.RMData[iCheckTask]['mainTask']):
                        continue
                    tmpTaskModel += self.getTaskModelFromRmData(self.RMData[iCheckTask]['mainTask']) + ' '
                    tmpTaskModel = tmpTaskModel.strip()                    
                    pass
                    
                if  -1 != tmpTaskModel.find('T'):
                    haveTForCommon = True
                else:
                    haveTForCommon = False                    
                if  -1 != tmpTaskModel.find('L'):
                    haveLForCommon = True
                else:
                    haveLForCommon = False
                    
                loopAddNum = 0
                for iTask in range(iRM + 1, iRM+1+excelFormatDef.RM_TASK_MAX_NUM):
                    if iTask >= len(self.RMData):
                        break
                    destSheetObject = []
                    destSheetName = []
                    if self.RMData[iTask]['mainTask'] == '':
                        break
                    loopAddNum = loopAddNum + 1
                    if not self.isTaskFromRmData(self.RMData[iTask]['mainTask']):
                        continue
                    apTaskName = self.getTaskNameFromRmData(self.RMData[iTask]['mainTask'])
                    apTaskType = self.getTaskTypeFromRmData(self.RMData[iTask]['taskType'])
                    taskModel = self.getTaskModelFromRmData(self.RMData[iTask]['mainTask'])
                    #print apTaskName, taskModel
                    # Lexus model:Common L T
                    if 'L' == taskModel:
                        # scrnHard: Dcu Meu DcuMeu errorList
                        destSheetObject.append(LexusSheet)
                        destSheetName.append('Lexus')
                    elif  'T' == taskModel:
                        # scrnHard: Dcu Meu DcuMeu errorList
                        destSheetObject.append(ToyotaSheet)
                        destSheetName.append('Toyota') 
                    elif 'Common' == taskModel:
                        if haveLForCommon:
                            destSheetObject.append(LexusSheet)
                            destSheetName.append('Lexus')
                        if haveTForCommon:
                            destSheetObject.append(ToyotaSheet)
                            destSheetName.append('Toyota')
                        pass
                        
                    # write destion excel file 
                    #print '@@@@@@@@@', destSheetName, len(destSheetObject)
                    if len(destSheetObject) <= 0:
                        # write errorlist sheet for having error  in data
                        print( '>>>>>>>>>>>>Redmine schedule format error,create mist object failed for %s' % ( self.RMData[iRM]['fatherTask']) )
                        noCreateScrn += self.RMData[iRM]['fatherTask'] + '\n'
                        #noScrnSheet.write(iRM, 0, self.RMData[iRM]['fatherTask'])
                    else:
                        #loop sheet object to write Anyplace info
                        sheetNameNo = 0
                        #print '@@@@@@@@@@', destSheetName
                        for sheetObj in destSheetObject:
                            # start to write data >>>>>>>>>>>>>>>>>>>>>>>>>>>.
                            # write AP summary title: screenID ScreenName summaryTask
                            tmpSheetName = destSheetName[sheetNameNo]
                            tmpSheetRow = sheetCurRowNum[tmpSheetName]
                            #print '@@@@@@@@@@', apTaskName
                            if -1 != apTaskName.find('Review'):
                                sheetObj.write(tmpSheetRow, excelFormatDef.AP_SCRN_UNIT_COL, self.RMData[iRM]['fatherTask'])
                                tmpSheetRow = tmpSheetRow + 1
                                strApSummaryTask = excelFormatDef.AP_TASK_CLASS_VAL_DESIGN % (scrnName)
                                sheetObj.write(tmpSheetRow, excelFormatDef.AP_TASK_CLASS_UNIT_COL, strApSummaryTask)
                                tmpSheetRow = tmpSheetRow + 1
                            if -1 != apTaskName.find('Coding'):
                                strApSummaryTask = excelFormatDef.AP_TASK_CLASS_VAL_CODE % (scrnName)
                                sheetObj.write(tmpSheetRow, excelFormatDef.AP_TASK_CLASS_UNIT_COL, strApSummaryTask)
                                tmpSheetRow = tmpSheetRow + 1
                            if -1 != apTaskName.find(u'試験書作成'):
                                strApSummaryTask = excelFormatDef.AP_TASK_CLASS_VAL_TEST % (scrnName)
                                #print tmpSheetRow, excelFormatDef.AP_TASK_CLASS_VAL_TEST, strApSummaryTask
                                sheetObj.write(tmpSheetRow, excelFormatDef.AP_TASK_CLASS_UNIT_COL, strApSummaryTask)
                                tmpSheetRow = tmpSheetRow + 1
                            # write taskName, startSchedule, endSchedule, taskMember, taskTimer, taskType
                            sheetObj.write(tmpSheetRow, excelFormatDef.AP_TASK_UNIT_COL, apTaskName)
                            sheetObj.write(tmpSheetRow, excelFormatDef.AP_START_SCHEDULE_COL, self.RMData[iTask]['startTimer'])
                            sheetObj.write(tmpSheetRow, excelFormatDef.AP_END_SCHEDULE_COL, self.RMData[iTask]['endTimer'])
                            sheetObj.write(tmpSheetRow, excelFormatDef.AP_MEMBER_UNIT_COL, self.RMData[iRM]['members'])
                            sheetObj.write(tmpSheetRow, excelFormatDef.AP_TASK_TIME_UNIT_COL, excelFormatDef.AP_TASK_TIME_VAL)
                            sheetObj.write(tmpSheetRow, excelFormatDef.AP_TASK_TYPE_UNIT_COL, apTaskType)
                            tmpSheetRow = tmpSheetRow + 1
                            sheetCurRowNum[tmpSheetName] = tmpSheetRow
                            sheetNameNo = sheetNameNo + 1
                            pass
                if not haveLForCommon:
                    modelNotAll += self.RMData[iRM]['fatherTask'] + ' have not lexus \n'
                if not haveTForCommon:
                    modelNotAll += self.RMData[iRM]['fatherTask'] + ' have not toyota \n'
                # print process programm
                print('>>>>>>>>>Finished FOR [%s] schedule transfer to Anyplace' % self.RMData[iRM]['fatherTask'])
                iRM = iRM + loopAddNum
                #print('write excel %d --- content %s' % (iRM, self.RMData[iRM]['fatherTask']))
                pass #   if self.RMData[iRM]['fatherTask'] != '':
        if '' != noCreateScrn:
            noScrnSheet.write(0, 0, u'Donnot find hard in scrnlist,donnot redmine to Anyplace:')
        else:
            noCreateScrn = 'GOOD! DONNOT FIND ERROR!'
        noScrnSheet.write(1, 0, noCreateScrn)
        noScrnSheet.write(2, 0, modelNotAll)
        ApDatabook.save('./ApDataNotFormat_Mist.xls')
        pass #def createMistAnyplace(self):
                
    def createScrnAnyplace(self, createType):
        #load excel data
        self.loadRedmineData(createType)
        self.loadScrnListData()
        #print '$$$$$$$', len(self.RMData),  self.RMData[-1]['mainTask']
        #return
        # add hard-model data xls
        ApDatabook = xlwt.Workbook(encoding='utf-8')
        dcuLexusWideSheet = ApDatabook.add_sheet('DcuLexusWide', cell_overwrite_ok=True)
        dcuLexusNarrowSheet = ApDatabook.add_sheet('DcuLexusNarrow', cell_overwrite_ok=True)
        dcuToyotaSheet = ApDatabook.add_sheet('DcuToyota', cell_overwrite_ok=True)
        meuLexusSheet = ApDatabook.add_sheet('MeuLexus', cell_overwrite_ok=True)
        meuToyotaSheet = ApDatabook.add_sheet('MeuToyota', cell_overwrite_ok=True)
        noScrnSheet = ApDatabook.add_sheet('errorList', cell_overwrite_ok=True)
        tmpApStartRow = excelFormatDef.AP_SHEET_START_ROW
        sheetCurRowNum = {'dcuLexusWide':tmpApStartRow, 'dcuLexusNarrow':tmpApStartRow, 'dcuToyota':tmpApStartRow,'meuLexus':tmpApStartRow,'meuToyota':tmpApStartRow}
        noCreateScrn = ''
        modelNotAll = ''
        createInfo = []
        for iRM in range(0, len(self.RMData)):
            #print rmData['fatherTask']
            scrnHard = ''
            scrnName = ''
            taskModel = ''
            apTaskName = ''
            apTaskType = ''
            if self.RMData[iRM]['fatherTask'] != '':
                # save ToSheet value 
                aryToSheet = []
                # return string: Dcu Meu DcuMeu errorList
                scrnHard = self.getHardFromSLData(self.RMData[iRM]['fatherTask'])
                scrnName = self.getScrnNameFromRmData(self.RMData[iRM]['fatherTask'])
                # return string: Wide Narrow Common errorDisplay
                scrnDisplay = self.getDisplayFromSLData(self.RMData[iRM]['fatherTask'])
                # check There is really T or L, when there is Common
                tmpTaskModel = ''
                haveTForCommon = False
                haveLForCommon = False
                for iCheckTask in range(iRM + 1, iRM+1+excelFormatDef.RM_TASK_MAX_NUM):
                    #print '$$$$$', iCheckTask
                    if iCheckTask >= len(self.RMData):
                        break
                    if self.RMData[iCheckTask]['mainTask'] == '':
                        break
                    if  self.isTaskFromRmData(self.RMData[iCheckTask]['mainTask']):
                        continue
                    tmpTaskModel += self.getTaskModelFromRmData(self.RMData[iCheckTask]['mainTask']) + ' '
                    tmpTaskModel = tmpTaskModel.strip()                    
                    pass
                
                if -1 != tmpTaskModel.find('T'):
                    haveTForCommon = True
                else:
                    haveTForCommon = False                    
                if  -1 != tmpTaskModel.find('L'):
                    haveLForCommon = True
                else:
                    haveLForCommon = False
                #print '@@@@@@@@@@@@@@@@@@@@@@@', scrnName, tmpTaskModel, haveTForCommon, haveLForCommon
                loopAddNum = 0
                for iTask in range(iRM + 1, iRM+1+excelFormatDef.RM_TASK_MAX_NUM):
                    if iTask >= len(self.RMData):
                        break
                    destSheetObject = []
                    destSheetName = []
                    if self.RMData[iTask]['mainTask'] == '':
                        break
                    loopAddNum = loopAddNum + 1
                    if not self.isTaskFromRmData(self.RMData[iTask]['mainTask']):
                        continue
                    apTaskName = self.getTaskNameFromRmData(self.RMData[iTask]['mainTask'])
                    apTaskType = self.getTaskTypeFromRmData(self.RMData[iTask]['taskType'])
                    taskModel = self.getTaskModelFromRmData(self.RMData[iTask]['mainTask'])
                    #print apTaskName, taskModel
                    # Lexus model:Common L T
                    if 'L' == taskModel:
                        #print '>>>>>>>>>>>>', scrnHard, scrnHard == 'Meu'
                        # scrnHard: Dcu Meu DcuMeu errorList
                        if scrnHard == 'Dcu':
                            if scrnDisplay == 'Wide':
                                destSheetObject.append(dcuLexusWideSheet)
                                destSheetName.append('dcuLexusWide')
                            elif scrnDisplay == 'Narrow':
                                destSheetObject.append(dcuLexusNarrowSheet)
                                destSheetName.append('dcuLexusNarrow')
                            else:
                                destSheetObject.append(dcuLexusWideSheet)
                                destSheetName.append('dcuLexusWide')
                                destSheetObject.append(dcuLexusNarrowSheet)
                                destSheetName.append('dcuLexusNarrow')
                        elif scrnHard == 'Meu':
                            destSheetObject.append(meuLexusSheet)
                            destSheetName.append('meuLexus')
                            #print '>>>>>>>>>>>>', destSheetName, destSheetObject
                        elif scrnHard == 'DcuMeu':
                            if scrnDisplay == 'Wide':
                                destSheetObject.append(dcuLexusWideSheet)
                                destSheetName.append('dcuLexusWide')
                            elif scrnDisplay == 'Narrow':
                                destSheetObject.append(dcuLexusNarrowSheet)
                                destSheetName.append('dcuLexusNarrow')
                            else:
                                destSheetObject.append(dcuLexusWideSheet)
                                destSheetName.append('dcuLexusWide')
                                destSheetObject.append(dcuLexusNarrowSheet)
                                destSheetName.append('dcuLexusNarrow')
                            destSheetObject.append(meuLexusSheet)
                            destSheetName.append('meuLexus')
                        else:
                            pass
                    elif  'T' == taskModel:
                        # scrnHard: Dcu Meu DcuMeu errorList
#                        if -1 != apTaskName.find('DesignCheck'):
#                            print '<<<<<<<<<<<<<<<<<<<TaskName-T', apTaskName, apTaskType
                        if scrnHard == 'Dcu':
                            destSheetObject.append(dcuToyotaSheet)
                            destSheetName.append('dcuToyota')
                        elif scrnHard == 'Meu':
                            destSheetObject.append(meuToyotaSheet)
                            destSheetName.append('meuToyota')
                        elif scrnHard == 'DcuMeu':
                            destSheetObject.append(dcuToyotaSheet)
                            destSheetName.append('dcuToyota')
                            destSheetObject.append(meuToyotaSheet)
                            destSheetName.append('meuToyota')
                        else:
                            pass      
                    elif 'Common' == taskModel:
                        if scrnHard == 'Dcu':
                            if haveLForCommon:
                                if scrnDisplay == 'Wide':
                                    destSheetObject.append(dcuLexusWideSheet)
                                    destSheetName.append('dcuLexusWide')
                                elif scrnDisplay == 'Narrow':
                                    destSheetObject.append(dcuLexusNarrowSheet)
                                    destSheetName.append('dcuLexusNarrow')
                                else:
                                    destSheetObject.append(dcuLexusWideSheet)
                                    destSheetName.append('dcuLexusWide')
                                    destSheetObject.append(dcuLexusNarrowSheet)
                                    destSheetName.append('dcuLexusNarrow')
                            if haveTForCommon:
                                destSheetObject.append(dcuToyotaSheet)
                                destSheetName.append('dcuToyota')
                        elif scrnHard == 'Meu':
                            if haveLForCommon:
                                destSheetObject.append(meuLexusSheet)
                                destSheetName.append('meuLexus')
                            if haveTForCommon:
                                destSheetObject.append(meuToyotaSheet)
                                destSheetName.append('meuToyota')
                        elif scrnHard == 'DcuMeu':
                            if haveLForCommon:
                                if scrnDisplay == 'Wide':
                                    destSheetObject.append(dcuLexusWideSheet)
                                    destSheetName.append('dcuLexusWide')
                                elif scrnDisplay == 'Narrow':
                                    destSheetObject.append(dcuLexusNarrowSheet)
                                    destSheetName.append('dcuLexusNarrow')
                                else:
                                    destSheetObject.append(dcuLexusWideSheet)
                                    destSheetName.append('dcuLexusWide')
                                    destSheetObject.append(dcuLexusNarrowSheet)
                                    destSheetName.append('dcuLexusNarrow')
                                destSheetObject.append(meuLexusSheet)
                                destSheetName.append('meuLexus')
                            if haveTForCommon:
                                destSheetObject.append(dcuToyotaSheet)
                                destSheetName.append('dcuToyota')
                                destSheetObject.append(meuToyotaSheet)
                                destSheetName.append('meuToyota')
                        else:
                            pass
                        pass
                        
                    # write destion excel file 
                    #print '@@@@@@@@@', destSheetName, len(destSheetObject)
                    if len(destSheetObject) <= 0:
                        # write errorlist sheet for having error  in data
                        print( '>>>>>>>>>>>>find hard-model object failed for %s' % ( self.RMData[iRM]['fatherTask']) )
                        noCreateScrn += self.RMData[iRM]['fatherTask'] + '\n'
                    else:
                        #loop sheet object to write Anyplace info
                        sheetNameNo = 0
                        #print '@@@@@@@@@@', destSheetName
                        # save ToSheet value 
                        if(len(aryToSheet)<=0):
                            for iTmp in range(0, len(destSheetName)):
                                aryToSheet.append(destSheetName[iTmp])
                                
                        for sheetObj in destSheetObject:
                            # start to write data >>>>>>>>>>>>>>>>>>>>>>>>>>>.
                            # write AP summary title: screenID ScreenName summaryTask
                            tmpSheetName = destSheetName[sheetNameNo]
                            tmpSheetRow = sheetCurRowNum[tmpSheetName]
                            #print '@@@@@@@@@@', apTaskName
                            if -1 != apTaskName.find('Review'):
                                sheetObj.write(tmpSheetRow, excelFormatDef.AP_SCRN_UNIT_COL, self.RMData[iRM]['fatherTask'])
                                tmpSheetRow = tmpSheetRow + 1
                                strApSummaryTask = excelFormatDef.AP_TASK_CLASS_VAL_DESIGN % (scrnName)
                                sheetObj.write(tmpSheetRow, excelFormatDef.AP_TASK_CLASS_UNIT_COL, strApSummaryTask)
                                tmpSheetRow = tmpSheetRow + 1
                            if -1 != apTaskName.find('Coding'):
                                strApSummaryTask = excelFormatDef.AP_TASK_CLASS_VAL_CODE % (scrnName)
                                sheetObj.write(tmpSheetRow, excelFormatDef.AP_TASK_CLASS_UNIT_COL, strApSummaryTask)
                                tmpSheetRow = tmpSheetRow + 1
                            if -1 != apTaskName.find('TestProgram'):
                                strApSummaryTask = excelFormatDef.AP_TASK_CLASS_VAL_TEST % (scrnName)
                                #print tmpSheetRow, excelFormatDef.AP_TASK_CLASS_VAL_TEST, strApSummaryTask
                                sheetObj.write(tmpSheetRow, excelFormatDef.AP_TASK_CLASS_UNIT_COL, strApSummaryTask)
                                tmpSheetRow = tmpSheetRow + 1
                            # write taskName, startSchedule, endSchedule, taskMember, taskTimer, taskType
                            sheetObj.write(tmpSheetRow, excelFormatDef.AP_TASK_UNIT_COL, apTaskName)
                            sheetObj.write(tmpSheetRow, excelFormatDef.AP_START_SCHEDULE_COL, self.RMData[iTask]['startTimer'])
                            sheetObj.write(tmpSheetRow, excelFormatDef.AP_END_SCHEDULE_COL, self.RMData[iTask]['endTimer'])
                            sheetObj.write(tmpSheetRow, excelFormatDef.AP_MEMBER_UNIT_COL, self.RMData[iRM]['members'])
                            sheetObj.write(tmpSheetRow, excelFormatDef.AP_TASK_TIME_UNIT_COL, excelFormatDef.AP_TASK_TIME_VAL)
                            sheetObj.write(tmpSheetRow, excelFormatDef.AP_TASK_TYPE_UNIT_COL, apTaskType)
                            tmpSheetRow = tmpSheetRow + 1
                            # add (Design) Task 
                            if -1 != tmpSheetName.find('meu') and -1 != apTaskName.find('Coding') and -1==self.RMData[iRM]['fatherTask'].find('MM_16'):
                                # RMAP_TMP_TASK_NAME = u'Coding(Design対応)'
                                sheetObj.write(tmpSheetRow, excelFormatDef.AP_TASK_UNIT_COL, excelFormatDef.RMAP_TMP_TASK_NAME)
                                sheetObj.write(tmpSheetRow, excelFormatDef.AP_START_SCHEDULE_COL, self.RMData[iTask]['endTimer']-4)
                                sheetObj.write(tmpSheetRow, excelFormatDef.AP_END_SCHEDULE_COL, self.RMData[iTask]['endTimer'])
                                sheetObj.write(tmpSheetRow, excelFormatDef.AP_MEMBER_UNIT_COL, self.RMData[iRM]['members'])
                                sheetObj.write(tmpSheetRow, excelFormatDef.AP_TASK_TIME_UNIT_COL, excelFormatDef.AP_TASK_TIME_VAL)
                                sheetObj.write(tmpSheetRow, excelFormatDef.AP_TASK_TYPE_UNIT_COL, apTaskType)
                                tmpSheetRow = tmpSheetRow + 1                          
                                pass
                                
                            sheetCurRowNum[tmpSheetName] = tmpSheetRow
                            sheetNameNo = sheetNameNo + 1
                            pass
                #output create info
                unitCreateInfo = ''
                unitCreateInfo += self.RMData[iRM]['fatherTask'] + '=> hard:' +  scrnHard +'  '+tmpTaskModel.replace('Common', 'model:')+ '  display:' + scrnDisplay
                unitCreateInfo += '  ToSheet: ' + ';'.join(aryToSheet) + '\n'
                #print '#########',aryToSheet, unitCreateInfo
                createInfo.append(unitCreateInfo)
                if not haveLForCommon:
                    modelNotAll += self.RMData[iRM]['fatherTask'] + ' have not lexus \n'
                if not haveTForCommon:
                    modelNotAll += self.RMData[iRM]['fatherTask'] + ' have not toyota \n'
                # print process programm
                print('>>>>>>>>>Finished FOR [%s] schedule transfer to Anyplace' % self.RMData[iRM]['fatherTask'])
                iRM = iRM + loopAddNum
                #print('write excel %d --- content %s' % (iRM, self.RMData[iRM]['fatherTask']))
                pass #   if self.RMData[iRM]['fatherTask'] != '':
        if '' != noCreateScrn:
            noScrnSheet.write(0, 0, u'Donnot find hard in scrnlist,donnot redmine to Anyplace:')
        else:
            noCreateScrn = 'GOOD! DONNOT FIND ERROR!'
        noScrnSheet.write(1, 0, noCreateScrn)
        noScrnSheet.write(2, 0, modelNotAll)
        for iRowTmp in range(3, len(createInfo)):
            noScrnSheet.write(iRowTmp, 0, createInfo[iRowTmp])
        ApDatabook.save('./ApDataNotFormat_Scrn.xls')
        pass #def createAnyplace(self, createType):
        
    pass #class RedmineToAP():
    
def runCreateScrnCmd(createType, RMFile, SLFile):
    if createType != excelFormatDef.RMAP_CREATE_TYPE_SCRN:
        print ' ERROR ^^^^^^create type is input error,createType value is {scrn,mist},please input right parameters!'
        return
    if not os.path.exists(RMFile)  or not os.path.exists(SLFile) :
        print ' ERROR ^^^^^^File is not exist,please input right parameters!'
        return
    #start to create anyplace from redmineScheduleFile
    createObj = RedmineToAP( RMFile)
    createObj.setScrnListFileAddr(SLFile)
    createObj.createScrnAnyplace(createType)        
    pass
    
def runCreateMistCmd(createType, RMFile):
    if createType != excelFormatDef.RMAP_CREATE_TYPE_MIST:
        print ' ERROR ^^^^^^create type is input error,createType value is {scrn,mist},please input right parameters!'
        return
    if not os.path.exists(RMFile) :
        print ' ERROR ^^^^^^File is not exist,please input right parameters!'
        return
    #start to create anyplace from redmineScheduleFile
    createObj = RedmineToAP( RMFile)
    createObj.createMistAnyplace(createType)        
    pass    

#########################################3
# start to report schdule

class ReportFromRMToAP():
    def __init__(self, ApExportXls, redmineExportXls):
        self.APDataXls = ApExportXls
        self.RMDataXls = redmineExportXls
        self.RMDataList = []
        self.APDataList = []
        self.ApExcelFile = None
        self.LoadRMDataOK = False
        self.LoadApDataOK = False
        self.APInputDataType = AP_TOYOTA_DATA
        
        #data load
        self.loadRedmineData()
        self.loadApData()
        pass
        
    def loadRedmineData(self):
        try:
            XlsFile = xlsRWLib(self.RMDataXls)
            XlsFile.openReadExcel()
            strSheetName = excelFormatDef.RM_DATA_SHEET_NAME
            taskName = XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_TASK, 1 )
            endSchedule = XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_FINISH_DAILY, 1 )
            taskProgress = XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_PROGRESS, 1 )
            taskTimer = XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_TIMER, 1 )
            taskComment = XlsFile.getColVal(strSheetName, excelFormatDef.RM_COL_COMMENT, 1 )
            self.LoadRMDataOK = True
        except:
            self.LoadRMDataOK = False
            print('>>>>>ERROR: open %s excel file failed,please input the address is ok?!' % (self.RMDataXls))
            return
        for i in range(0, len(taskName)):
            self.RMDataList += [{'taskName':taskName[i],'endSchedule':endSchedule[i],'taskProgress':taskProgress[i],'taskTimer':taskTimer[i],'taskComment':taskComment[i]}]
        pass
        
    def loadApData(self):
        try:
            self.ApExcelFile = xlsRWLib(self.APDataXls)
            self.ApExcelFile.openReadExcel()
            apTask = self.ApExcelFile.getColVal(excelFormatDef.AP_DATA_SHEET_NAME, excelFormatDef.AP_COL_DATA_IN_TASK, 5 )
            taskFlag = self.ApExcelFile.getColVal(excelFormatDef.AP_DATA_SHEET_NAME, excelFormatDef.AP_COL_DATA_IN_TASK_FLAG, 5 )
            finishDaily = self.ApExcelFile.getColVal(excelFormatDef.AP_DATA_SHEET_NAME, excelFormatDef.AP_COL_DATA_IN_OLD_FINISH, 5 )
            # read Anyplace data type  read cell I3 data
            strApProjName = self.ApExcelFile.getCellVal(excelFormatDef.AP_DATA_SHEET_NAME, 2, 8)
            if -1 != strApProjName.find('-L') or  -1 != strApProjName.find('_L'):
                self.APInputDataType = AP_LEXUS_DATA
            else:
                self.APInputDataType = AP_TOYOTA_DATA
            self.LoadApDataOK = True
        except:
            self.LoadApDataOK = False
            print('>>>>>ERROR: open %s excel file failed,please input the address is ok?!' % (self.APDataXls))
            return
        for i in range(0, len(apTask)):
            self.APDataList += [{'apTask':apTask[i],'taskFlag':taskFlag[i],'finishDaily':finishDaily[i]}]
        pass
        
    def workDailyForAp(self, apOldDaily):
        strTimer = time.strftime('%Y-%2m-%2d',time.localtime(time.time()))
        #print '%%%%%%%%%%%%%%%%%%%', strTimer
        return strTimer
        pass
        
    def workTimerHourForAp(self, rmTimer):
        rmTaskTimerVal = 0
        if '' == rmTimer:
            rmTaskTimerVal = 2.5
        else:
            rmTaskTimerVal = float(rmTimer)
        iMin = rmTaskTimerVal * 60
        return str(int(iMin/60))
        pass
        
    def workTimerMinForAp(self, rmTimer):
        rmTaskTimerVal = 0
        if '' == rmTimer:
            rmTaskTimerVal = 2.5
        else:
            rmTaskTimerVal = float(rmTimer)
        if 0.0 == rmTaskTimerVal:
            return '00'
        #print '^^^^^^^^^',  rmTaskTimerVal
        iMin = rmTaskTimerVal * 60
        iWorkMin = iMin%60
        iWorkMin = (int(iWorkMin/15))*15
        #print '^^^^^^^^^',  iWorkMin
        iWorkMin = '%02d' % iWorkMin
        return str(iWorkMin)
        pass
        
    def workProgressForAp(self, rmProgress):
        #print '&&&&&&&&&&&&&&&&&&&&', rmProgress
        # 10% unit
        iNewProgress = int(rmProgress)
        
        iNewProgressMod = iNewProgress%10
        if iNewProgressMod > 0:
            iNewProgressTmp1= (int(iNewProgress/10)+1)*10
            if iNewProgressTmp1 >= 100:
                iNewProgress = 90
            else:
                iNewProgress = iNewProgressTmp1
        else:
            iNewProgress = int(rmProgress)
            
        return iNewProgress
        pass        

    def workCommentForAp(self, rmComment):
        return rmComment
        pass
    
    # compture excel daily
    def comptureFloatDailyFromStr(self, strDaily):
        #the format of strDaily: XXXX-XX-XX 2015-03-21
        if '' == strDaily:
            return 0.0
        strDailyDataList = strDaily.split('-')
        if 4 != len(strDailyDataList[0]) or 3 != len(strDailyDataList):
            return 0.0
        arryMonthDaily = {1:31, 2:28, 3:31, 4:30, 5:31, 6:30, 7:31, 8:31, 9:30, 10:31, 11:30, 12:31}
        #floatYear = float(strDailyDataList[0]) - 1900
        intYear = int(strDailyDataList[0]) - 1900
        intMonth = int(strDailyDataList[1])
        intDay = int(strDailyDataList[2])
        #__s_date = datetime.date(1899, 12, 31).toordinal()-1
        #allDay = datetime.datetime(intYear,intMonth, intDay)
        monthDay = 0
        for iM in range(1, intMonth):
            monthDay += arryMonthDaily[iM]
#        # normal year?
#        noNormalYear = 0
#        for iY in range(1, int(float(strDailyDataList[0]))):
#            if iY % 400 == 0:
#               noNormalYear = noNormalYear + 1 
        # normal year?
#        noNormalYear = 2    #i donnot known  the compture methion of excel, it is error at here
#        for iY in range(1, int(floatYear)):
#            tmp4Y = iY%4
#            tmp100Y = iY%100
#            tmp400Y = iY%400 
#            if (tmp4Y==0 and tmp100Y!=0) or tmp400Y==0:
#                print '11################################',iY
#                noNormalYear = noNormalYear + 1    
        noNormalYear = (intYear+ 1) / 4
        allDay = intYear*365 + monthDay + intDay + noNormalYear
        #print '&&&&&&&&', allDay, intYear, intMonth, intDay
        return allDay
        pass
        
    def comptureStrDailyFromFloat(self, floatDaily):
        if 0 >= floatDaily:
            return '0000-00-00'
#        intDay = int(floatDaily)
#        intYear = intDay/365 + 1900
#        # normal year?
##        noNormalYear = 2     #i donnot known  the compture methion of excel, it is error at here
##        for iY in range(1, intYear-1900):
##            tmp4Y = iY%4
##            tmp100Y = iY%100
##            tmp400Y = iY%400 
##            if (tmp4Y==0 and tmp100Y!=0) or tmp400Y==0:
##                #print '22################################',iY
##                noNormalYear = noNormalYear + 1         
#        noNormalYear = (int(intDay/365) + 1) / 4
#        intDay = intDay - noNormalYear
#        intMonthDay = intDay%365
#        arryMonthDaily = {1:31, 2:28, 3:31, 4:30, 5:31, 6:30, 7:31, 8:31, 9:30, 10:31, 11:30, 12:31}
#        tmpMonthDay = 0
#        trueMonth = 0
#        for iM in range(1, 12):
#            tmpMonthDay += arryMonthDaily[iM]
#            if intMonthDay - tmpMonthDay < 0:
#                trueMonth = iM
#                break
#        monthDay = 0
#        for iM in range(1, trueMonth):
#            monthDay += arryMonthDaily[iM]
#        trueDay = intMonthDay - monthDay
#        if trueMonth <= 0:
#            trueMonth = 1
#        elif trueMonth >= 13:
#            trueMonth = trueMonth - 12
#        else:
#            pass
#        if trueDay <= 0:
#            trueMonth = trueMonth - 1
#            trueDay = arryMonthDaily[trueMonth]            
#        
#        strDaily = str(intYear) + '-' + str(trueMonth)  + '-' + str(trueDay)

        __s_date = datetime.date(1899, 12, 31).toordinal()-1
        if isinstance(floatDaily, float):
            date = int(floatDaily)
        newDate = datetime.date.fromordinal(__s_date + date)
        #print  '&&&&&&&&', strDaily, intYear, trueMonth, trueDay, noNormalYear
        strDate = newDate.strftime('%Y-%2m-%2d')
        return strDate
        pass
        
    def workNewEndDailyForAp(self, rmNewDaily, apOldDaily):
        floatApOldDaily = 0
        floatNewDaily = 0
        if isinstance(apOldDaily, str):
            floatApOldDaily = self.comptureFloatDailyFromStr(apOldDaily)
        else:
            floatApOldDaily = apOldDaily
        if isinstance(rmNewDaily, str):
            floatNewDaily = self.comptureFloatDailyFromStr(rmNewDaily)
        else:
            floatNewDaily = rmNewDaily
#        else:
#            floatNewDaily = rmNewDaily
        #floatApOldDaily = self.comptureFloatDailyFromStr(apOldDaily)
#        if not isinstance(rmNewDaily, float):
#            floatNewDaily = self.comptureFloatDailyFromStr(rmNewDaily)
#        else:
#            floatNewDaily = rmNewDaily
        if floatNewDaily < floatApOldDaily:
            return 'NewDateError'
        elif floatNewDaily == floatApOldDaily:
            return ''
        else:
            pass # donothing
        #print '&&&&&&&&', rmNewDaily, apOldDaily, floatNewDaily, floatApOldDaily, isinstance(apOldDaily, str), isinstance(rmNewDaily, str), isinstance(rmNewDaily, float)
        if not isinstance(rmNewDaily, float):
            strNewDaily = rmNewDaily
        else:
            strNewDaily = self.comptureStrDailyFromFloat(rmNewDaily)
        #print '&&&&&&&&', rmNewDaily, apOldDaily, floatNewDaily, floatApOldDaily, strNewDaily
        return strNewDaily
        pass
        
    def reportSchedule(self):
        
        # loop ap's task to get redmine task name
        #print len(self.APDataList['apTask'])
        #print (self.APDataList['apTask'])
        
        # check data load success?
        if not self.LoadApDataOK or not self.LoadRMDataOK:
            print '#####>>>>>>>##### Have Error! RUN STOP!!!!!!'
            return
        
        self.ApExcelFile.openWriteExcel()
        for iAp in range(0, len(self.APDataList)):
            # is it screen name: screen task startFlag
            if -1 != self.APDataList[iAp]['apTask'].find('MM') and excelFormatDef.AP_DATA_IN_TASK_FLAG_VAL == self.APDataList[iAp]['taskFlag']:
                # new loop for screen task
                iNewApLoop = iAp + 2
                strScrnName = self.APDataList[iAp]['apTask'].strip()
                for iNewApLoop in range(iAp + 2, iAp + excelFormatDef.AP_DATA_MAX_TASK_ROW):
                    if iNewApLoop > len(self.APDataList) - 1:
                        break
                    if -1 != self.APDataList[iNewApLoop]['apTask'].find('MM') and excelFormatDef.AP_DATA_IN_TASK_FLAG_VAL == self.APDataList[iNewApLoop]['taskFlag']:
                        break
                    # get redmine'task name
                    strRmTaskNameTmp = ''
                    strRmTaskName = []
                    if excelFormatDef.AP_DATA_IN_TASK_FLAG_VAL != self.APDataList[iNewApLoop]['taskFlag']:
                        strRmTaskNameTmp = self.APDataList[iNewApLoop]['apTask'].strip() + '_' + strScrnName
                    if '' == strRmTaskNameTmp:
                        continue
                    # add _L _T _Common in the taskname
                    if -1 != strRmTaskNameTmp.find(u'・'):
                        strRmTaskNameTmp = strRmTaskNameTmp.replace(u'・','?')
                    strTName = ''
                    if AP_LEXUS_DATA == self.APInputDataType:
                        strTName = strRmTaskNameTmp + '_L'
                        strRmTaskName.append(strTName)
                    else:
                        strTName = strRmTaskNameTmp + '_T'
                        strRmTaskName.append(strTName)
                    strTName = strRmTaskNameTmp + '_Common'
                    strRmTaskName.append(strTName)
                    
                    for strRmTask in strRmTaskName:
                        if '' != strRmTask:
                            # loop rmdatalist to find the progress of this task
                            print '>>>>>>>start to find task Anyplace Data {',  strRmTask,  ' }'
                            for iRm in range(0, len(self.RMDataList)):
                                if strRmTask == self.RMDataList[iRm]['taskName']:
                                    # write progress to anyplace's DataInput
                                    writeSheetIndex = self.ApExcelFile.getSheetIndexByName(excelFormatDef.AP_DATA_SHEET_NAME)
                                    strRowVal = []
                                    strRowVal.append(self.workDailyForAp(self.APDataList[iNewApLoop]['finishDaily']))
                                    #strRowVal.append(self.workTimerHourForAp(self.RMDataList['iRm']['taskName']))
                                    # donnot get timer, fix 2.5h
                                    strRowVal.append(self.workTimerHourForAp(self.RMDataList[iRm]['taskTimer']))
                                    strRowVal.append(self.workTimerMinForAp(self.RMDataList[iRm]['taskTimer']))
                                    strRowVal.append(self.workProgressForAp(self.RMDataList[iRm]['taskProgress']))
                                    # donnot get comment, fix null
                                    strRowVal.append(self.workCommentForAp(self.RMDataList[iRm]['taskComment']))
                                    strRowVal.append(self.workNewEndDailyForAp(self.RMDataList[iRm]['endSchedule'], self.APDataList[iNewApLoop]['finishDaily']))
                                    iApDataRow = excelFormatDef.AP_DATA_START_ROW + iNewApLoop
                                    print '>>>>Task', strRmTaskName, 'Anyplace Data is writed', '####',iApDataRow, '#' , strRowVal, '<<<<<'
                                    self.ApExcelFile.setRowVal(writeSheetIndex, iApDataRow,  strRowVal,  excelFormatDef.AP_COL_DATA_IN_WORK_DAILY , excelFormatDef.AP_COL_DATA_IN_NEW_FINISH, True)
                                    
                                    break
                                    pass
                            pass
                        pass # for strRmTask in strRmTaskName
                    pass # for iNewApLoop
                iAp = iAp + iNewApLoop - 1
                pass # if -1 != self.APDataList[iAp]['apTask'].find('MM')
            pass # for iAp in range(0, len(self.APDataList))
            self.ApExcelFile.saveExcel()
        pass # reportSchedule

    pass # ReportFromRMToAP class
    
def runReportCmd(ApExportXls, redmineExportXls):
    if not os.path.exists(ApExportXls)  or not os.path.exists(redmineExportXls) :
        print ' ERROR ^^^^^^File is not exist,please input right parameters!'
        return
    reportObj = ReportFromRMToAP(ApExportXls, redmineExportXls)
    reportObj.reportSchedule()
    pass


def printHelp():
    print '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>'
    print 'use methion case1:create anyplace Schedule. \n ./redmineToAP.py --create --createType redmineScheduleFile screenListFile'
    print 'createType value is {scrn,mist},other valune cannot use'
    print 'if createType is mist, it need not to set screenListFile param '
    print 'use methion case2:report anyplace Schedule. \n ./redmineToAP.py --report TaskForDataInputExcel redmineExportExcel'
    pass
    
def main():
    # load programm's argc
    argvLen = len(sys.argv) - 1
    if argvLen > 0:    
        if '--help' == sys.argv[1]:
            printHelp()
        elif '--create' == sys.argv[1]:
            if '--scrn' == sys.argv[2]:
                if argvLen < 4:
                    print ' ERROR ^^^^^^command param is not enough'
                    printHelp()
                else:
                    #run create command
                    runCreateScrnCmd(sys.argv[2], sys.argv[3], sys.argv[4])
                    pass
            else: # --mist
                if argvLen < 3:
                    print ' ERROR ^^^^^^command param is not enough'
                    printHelp()
                else:
                    #run create command
                    runCreateMistCmd(sys.argv[2], sys.argv[3])
                pass 
            pass
        elif '--report' == sys.argv[1]:
            if argvLen < 3:
                print ' ERROR ^^^^^^command param is not enough'
                printHelp()
            else:
                #run report command
                runReportCmd(sys.argv[2], sys.argv[3])
                pass            
            pass
        else:
            print ' ERROR ^^^^^^input command parameters have error'
            printHelp()
    else:
        print ' ERROR ^^^^^^please input command parameters'
        printHelp()    
    pass
    
if __name__ == '__main__':
    main()
    pass
