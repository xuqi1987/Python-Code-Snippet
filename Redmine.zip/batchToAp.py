#!/usr/bin/env python
#-*- coding:utf-8 -*-
# author: liujun@pset.suntec.net
# Modify LOG: 
# 2015/4/7  15:00 new create
# 2015/4/17 12:00 modify output log for redmine whether outputlog have error log

import os
import sys

def runCmd(strCmd):
    print('@@@@@@start to run command: %s' % (strCmd))
    cmdReturn = os.system(strCmd)
    if 0 != cmdReturn:
        print('@@@@@@@command %s run fail!' % (strCmd))
            
def main(strFilePath):
    if '' == strFilePath:
        print '-->> Error: file path had been input! please check...'
        return
    # get all file in this file
    # redmine file: issues; anyplace file: TaskForDataInput
    fileList = os.listdir(strFilePath)
    taskRMFile = []
    taskAPFile = []
    for f in fileList:
        filepath = os.path.join(strFilePath, f) 
        if  f.startswith('.') or os.path.isdir(filepath):
            continue
        if -1 != f.find("issues"):
            taskRMFile.append(filepath)
        if -1 != f.find("TaskForDataInput"):
            taskAPFile.append(filepath)
        pass # for f in fileList
    #print '########',taskRMFile,'###',taskAPFile
    for apFile in taskAPFile:        
        for rmFile in taskRMFile:
            strcmd = './redmineToAP.py --report '
            strcmd += apFile + ' ' + rmFile
            runCmd(strcmd)
        pass # for apFile in taskAPFile:
    print '--->>> Run finished.please check log to know whether there is error log. if NoError,then import to anyplace...'
    pass
    
if __name__ == '__main__':
    argvLen = len(sys.argv) - 1
    print '--->>> start to run batch', argvLen, sys.argv
    if argvLen >= 1:
        main(sys.argv[1])
