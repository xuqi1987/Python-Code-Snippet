#!/usr/bin/env python
# -*- coding: utf-8 -*-

import xlrd
from xlwt import *
from xlutils.copy import copy
#from style import XFStyle

class xlsRWLib():
    """ 
    define excel read write module
    """

    def __init__(self,  __name):
        # define class var
        self.xlsName = __name
        self.OpenReadState = False
        self.xlsReadBook = None
        self.OpenWriteState = False
        self.xlsWriteBook = None
        
    def openReadExcel(self):
        try:
            self.xlsReadBook = xlrd.open_workbook(self.xlsName, formatting_info = True)
            self.OpenReadState = True
        except:
            self.OpenReadState = False
            self.xlsReadBook = None
            print("[openReadExcel] ERROR: %s excel file open failed!" % (self.xlsName))
        finally:
            pass
            
    def getCellVal(self, sheetName, cellR, cellC):
        if self.OpenReadState:
            try:
                excelSheet = self.xlsReadBook.sheet_by_name(sheetName)
                # test code
                #print ('this sheet AllRow %d and AllCol %d' % (excelSheet.nrows, excelSheet.ncols))
                return excelSheet.cell(cellR, cellC).value
            except:
                print("[getCellVal] ERROR: %s sheet read failed!" % (sheetName))
            finally:
                pass
        else:
            print("[getCellVal] INFO: Excel is not Opened!")
            
    def openWriteExcel(self):
        try:
            self.xlsWriteBook = copy(self.xlsReadBook)
            self.OpenWriteState = True
        except:
            self.OpenWriteState = False
            print '[openWriteExcel] ERROR: open excel failed for writing!'
    
    def setCellBorderAlig(self, Aligment):
        borders = Borders()  
        borders.left = 1  
        borders.right = 1  
        borders.top = 1  
        borders.bottom = 1  

        al = Alignment()  
        al.horz = Aligment#Alignment.HORZ_CENTER  
        al.vert = Alignment.VERT_CENTER  

        style = XFStyle()  
        style.borders = borders  
        style.alignment = al 
        
        return style
    
    def setCellVal(self, sheetName, cellR, cellC, cellValue, haveBorder=False):
        if not self.OpenWriteState:
            self.openWriteExcel()
        else:
            #do nothing
            pass
            
        if self.OpenWriteState:
            try:

                excelSheet = self.xlsWriteBook.get_sheet(sheetName)
                styleDef = Style.default_style
                if haveBorder:
                    styleDef = self.setCellBorderAlig(Alignment.HORZ_LEFT)
                excelSheet.write(cellR, cellC, cellValue, styleDef)
            except:
                print("[setCellVal] ERROR: %s sheet write failed!" % (sheetName))
            # except IOError,e: 
            #     print("open exception: %s: %s\n" %(e.errno, e.strerror)) 
            finally:
                pass
        else:
            print '[setCellVal] WARN: excel is open failed by write!'
            
    def saveExcel(self):
        self.xlsWriteBook.save(self.xlsName)
        
    ####################################
    def getRowVal(self, sheetName, nRow,  startCol=0, endCol=-1):
        # nRow ,startCol is start to 0,but endcol is start to 1
        # return array data which from startcol to endcol
        # if endcol is -1, get value for the lastest col
        rowVal = []
        endColVal = 0
        startColVal = 0
        nRowVal = 0
        
        # get sheet name
        if self.OpenReadState:
            try:
                excelSheet = self.xlsReadBook.sheet_by_name(sheetName)
            except:
                print("[getRowVal] ERROR: %s sheet read failed!" % (sheetName))
                return rowVal
        else:
            print("[getRowVal] INFO: Excel is not Opened!")
            return rowVal
            
        if -1 == endCol:
            endColVal = excelSheet.ncols
        else:
            endColVal = endCol
            
        if startCol <= 0:
            startColVal = 0
        elif startCol >= excelSheet.ncols:
            startColVal = 0
        else:
            startColVal = startCol
            
        if nRow <= 0:
            nRowVal = 0
        elif nRow >= excelSheet.nrows:
            nRowVal = excelSheet.nrows
        else:
            nRowVal = nRow
        
        for  nCol in range(startColVal, endColVal):
            rowVal.append(excelSheet.cell(nRowVal, nCol).value)
        
        return rowVal
        
    def getColVal(self, sheetName, nCol,  startRow=0,  endRow=-1):
        # nCol ,startRow is start to 0,but endRow is start to 1
        # return array data which from startrow to endrow
        # if endcol is -1, get value for the lastest col
        colVal = []
        endRowVal = 0
        startRowVal = 0
        nColVal = 0
        
        # get sheet name
        if self.OpenReadState:
            try:
                excelSheet = self.xlsReadBook.sheet_by_name(sheetName)
            except:
                print("[getColVal] ERROR: %s sheet read failed!" % (sheetName))
                return colVal
        else:
            print("[getColVal] INFO: Excel is not Opened!")
            return colVal
            
        if -1 == endRow:
            endRowVal = excelSheet.nrows
        else:
            endRowVal = endRow
            
        if startRow <= 0:
            startRowVal = 0
        elif startRow >= excelSheet.nrows:
            startRowVal = 0
        else:
            startRowVal = startRow
            
        if nCol <= 0:
            nColVal = 0
        elif nCol >= excelSheet.ncols:
            nColVal = excelSheet.ncols
        else:
            nColVal = nCol
        
        for  nRow in range(startRowVal, endRowVal):
            colVal.append(excelSheet.cell(nRow, nColVal).value)
        
        return colVal
        
    def setRowVal(self, sheetName, nRow,  rowVal,  startCol=0, endCol=-1, haveBorder=False):
        # nRow ,startCol is start to 0;but endCol is start to 1
        # set array data to excel which from startcol to endcol
        # if endcol is -1, get value for the lastest col
        endColVal = 0
        startColVal = 0
        rowValLen = len(rowVal)
        nRowVal = 0
        
        #print '@@@@@@@@ row len', rowValLen
        # get sheet name
        if self.OpenWriteState:
            try:
                excelSheet = self.xlsWriteBook.get_sheet(sheetName)
            except:
                print("[setRowVal] ERROR: %s sheet write failed!" % (sheetName))
                return
        else:
            print("[setRowVal] INFO: Excel is not Opened by write!")
            return
            
        if -1 == endCol:
            endColVal = excelSheet.ncols
        else:
            endColVal = endCol
            
        if startCol <= 0:
            startColVal = 0
        else:
            startColVal = startCol

        if nRow <= 0:
            nRowVal = 0
        else:
            nRowVal = nRow
            
        rowValCnt = 0
        #print '@@@@@@@@ start and end col', startColVal, endColVal
        for  nCol in range(startColVal, endColVal+1):
            #print '@@@@@@@@ loop col', nCol, rowValCnt
            styleDef = Style.default_style
            if haveBorder:
                    styleDef = self.setCellBorderAlig(Alignment.HORZ_LEFT)
            if rowValCnt < rowValLen:
                excelSheet.write(nRowVal, nCol, rowVal[rowValCnt], styleDef)
                #print('#####it is write sheet [%d,%d],content %s' % (nRowVal, nCol,rowVal[rowValCnt] ))
                rowValCnt = rowValCnt + 1
            else:
                excelSheet.write(nRowVal, nCol, '', styleDef)
                #print('@@@@@it is write sheet [%d,%d],content %s' % (nRowVal, nCol,rowVal[rowValCnt-1] ))

    def setColVal(self, sheetName, nCol,  colVal,  startRow=0, endRow=-1, haveBorder=False):
        # nCol ,startRow is start to 0;but endRow is start to 1
        # set array data to excel which from startRow to endRow
        # if endRow is -1, get value for the lastest col
        endRowVal = 0
        startRowVal = 0
        colValLen = len(colVal)
        nColVal = 0
        
        #print '@@@@@@@@ col len', colValLen
        # get sheet name
        if self.OpenWriteState:
            try:
                excelSheet = self.xlsWriteBook.get_sheet(sheetName)
            except:
                print("[setColVal] ERROR: %s sheet write failed!" % (sheetName))
                return
        else:
            print("[setColVal] INFO: Excel is not Opened by write!")
            return
            
        if -1 == endRow:
            endRowVal = excelSheet.ncols
        else:
            endRowVal = endRow
            
        if startRow <= 0:
            startRowVal = 0
        else:
            startRowVal = startRow

        if nCol <= 0:
            nColVal = 0
        else:
            nColVal = nCol
            
        colValCnt = 0
        #print '@@@@@@@@ start and end col', startRowVal, endRowVal
        for  nRow in range(startRowVal, endRowVal):
            #print '@@@@@@@@ loop row', colValCnt, nRow
            styleDef = Style.default_style
            if haveBorder:
                    styleDef = self.setCellBorderAlig(Alignment.HORZ_LEFT)
            if colValCnt < colValLen:
                excelSheet.write(nRow, nColVal, colVal[colValCnt], styleDef)
                #print('#####it is write sheet [%d,%d],content %s' % (nRow, nColVal,colVal[colValCnt] ))
                colValCnt = colValCnt + 1
            else:
                excelSheet.write(nRow, nColVal, '', styleDef)
                #print('@@@@@it is write sheet [%d,%d],content %s' % (nRow, nColVal,colVal[colValCnt]-1] ))

    #####################################
    def getSheetIndexByName(self, sheetName):
        allSheetName = []
        if self.OpenReadState:
            allSheetName = self.xlsReadBook.sheet_names()
        sheetIndex = 0
        for sheet in allSheetName:
            if sheet == sheetName:
                break
            sheetIndex = sheetIndex + 1
            
        return sheetIndex
        
# main run==>test code
if __name__ == '__main__':
    xlsFile = xlsRWLib('./ScreenClassList.xls')
    xlsFile.openReadExcel()
    cellValue=  xlsFile.getCellVal('Requst', 6, 7)
    print("Row8,Colume7=%s" % (cellValue))
    rowvalue = xlsFile.getRowVal('Requst', 7, 1, 13)
    colvalue = xlsFile.getColVal('Requst', 5, 1, 8)
    print rowvalue, colvalue
    #xlsFile.openWriteExcel()
    #xlsFile.setCellVal(1, 0, 0, 'chiese, i love you')
    #writeRow12Val = ['OK', 'NG', 'NG', 'NG', 'NG', 'NG', 'NG', 'NG']
    #xlsFile.setRowVal(1, 12, writeRow12Val, 9, 20,True) 
    #writeCol12Val = ['OK', 'NG', 'NG', 'NG', 'NG', 'NG', 'NG', 'NG']
    #xlsFile.setColVal(1, 12, writeCol12Val, 9, 20, True)  
    #xlsFile.saveExcel()
    print xlsFile.getSheetIndexByName('Requst')
    
